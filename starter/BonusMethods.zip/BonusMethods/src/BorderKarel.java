import stanford.karel.*;

public class BorderKarel extends SuperKarel {
	public void run() {
		// your code goes here...
	}
}

