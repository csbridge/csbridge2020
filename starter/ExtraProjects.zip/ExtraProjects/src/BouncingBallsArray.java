import acm.program.*;
import acm.graphics.*;
import acm.util.*;

import java.awt.Color;
import java.awt.event.*;
import java.util.ArrayList;

public class BouncingBallsArray extends GraphicsProgram {
	private static final double SIZE = 20;
	private static final int N_BALLS = 150;
	private static final int DELAY = 5;
	
	private GOval[] balls;
	private Double[] ballVx;
	private Double[] ballVy;
	private RandomGenerator rg = new RandomGenerator();
	
	/* Here is an example using arrays. I have included it in the
	 * starter code files for those that are curious, or who just want to run the file
	 * to see the animation. It displays the use of an array.
	 */
	public void run() {
		createBalls();
		while(true) {
			animateBalls();
			pause(DELAY);
		}
	}

	/* Animate one animation frame.*/
	private void animateBalls() {
		for(int i = 0; i < N_BALLS; i++) {
			GOval ball = balls[i];
			if(ball.getX() > getWidth() - SIZE || ball.getX() < 0) {
				reflectX(i);
			}
			if(ball.getY() > getHeight() - SIZE || ball.getY() < 0) {
				reflectY(i);
			}
			ball.move(ballVx[i], ballVy[i]);
			ball.setColor(rg.nextColor());
		}
	}
	
	/* Reflects a ball's Y-velocity. */
	private void reflectY(int i) {
		ballVy[i] = -ballVy[i];
	}
	
	/* Reflects a ball's X-velocity. */
	private void reflectX(int i) {
		ballVx[i] = -ballVx[i];
	}

	/* Creates the balls with a random X,Y location and a random velocity. */
	private void createBalls() {
		balls = new GOval[N_BALLS];
		ballVx = new Double[N_BALLS];
		ballVy = new Double[N_BALLS];
		for(int i = 0; i < N_BALLS; i++) {
			double x = rg.nextDouble(0, getWidth() - SIZE);
			double y = rg.nextDouble(0, getHeight()- SIZE);
			GOval ball = new GOval(x, y, SIZE, SIZE);
			ball.setFilled(true);
			ball.setColor(rg.nextColor());
			add(ball);
			balls[i] = ball;
			ballVx[i] = randomVelocity();
			ballVy[i] = randomVelocity();
		}
	}
	
	/* Return a random velocity. */
	private double randomVelocity() {
		return rg.nextDouble(0,1) > 0.5 ? rg.nextDouble(1, 3) : -rg.nextDouble(1, 3);
	}

}
