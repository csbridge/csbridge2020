import java.awt.Color;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import acm.graphics.GCompound;
import acm.graphics.GImage;
import acm.graphics.GLabel;
import acm.graphics.GLine;
import acm.graphics.GOval;
import acm.graphics.GRect;
import acm.program.GraphicsProgram;
/*
 * This project contains simple isolated examples for:
 * - Using GCompund objects
 * - Creating a graphical object containing of many graphical objects (see method createGraph)
 * - Reading images, resizing them and using them as part of graphical objects
 * - Using counter and displaying the count
 * */

public class GraphicsSample extends GraphicsProgram{
	
	public void run(){
		GCompound myCar=car(200,120,"driver.jpeg");
		GLine line2rotate = new GLine(50,50,100,50);
		GLabel counterLabel = new GLabel("Angle=0");
		add(myCar,0,getHeight()/2);
		add(line2rotate);
		add(counterLabel,100,50);
		int count=0;
		while(myCar.getWidth()+myCar.getX()<getWidth()) {
			myCar.move(1, 0);
			line2rotate.rotate(1);
			counterLabel.setLabel("Angle="+count);count++;
			pause(10);
		}
	}
	/**
	 * Method: car
	 * ----------------------
	 * Creates a 'car' made of a GRect, two GOvals and a GImage
	 */
	private GCompound car(int width,int height, String driverImgFileName) {
		//Creating an empty compound object
		GCompound carObj=new GCompound();
		//Adding main body
		GRect mainBody=new GRect(width,height/2);
		carObj.add(mainBody,0,height/4);
		//Adding tires
		GOval tire1=new GOval(width/5,height/2);
		GOval tire2=new GOval(width/5,height/2);
		carObj.add(tire1,width/5,height/2);
		carObj.add(tire2,width*3/5,height/2);
		//Adding an image in the compound object
		GImage driver = new GImage(driverImgFileName);
		driver.setSize(width/2, height/2);
		carObj.add(driver,width/4,0);
		//Design finished, return the object created
		return carObj;
	}
	
}
