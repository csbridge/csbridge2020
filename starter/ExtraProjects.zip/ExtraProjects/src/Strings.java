import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class Strings extends ConsoleProgram {
	
	
	public void run() {

	}
	
	/* Returns a string that is the reversed form of the original string
	 * passed into the method.
	 */
	private String reverse(String original) {
		String reversed = "";
		for (int i = 0; i < original.length(); i++) {
			char ch = original.charAt(i);
			reversed = ch + reversed;
		}
		return reversed;
	}
	
	/* Returns a boolean indicating whether or not the string passed in
	 * is a palindrome.
	 */
	private boolean isPalindrome(String original) {
		return reverse(original).equals(original);
	}
	
}
