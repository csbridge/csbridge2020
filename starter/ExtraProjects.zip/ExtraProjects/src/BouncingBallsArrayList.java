import acm.program.*;
import acm.graphics.*;
import acm.util.*;

import java.awt.Color;
import java.awt.event.*;
import java.util.ArrayList;

public class BouncingBallsArrayList extends GraphicsProgram {
	private static final int SIZE = 20;
	private static final int MAX_BALLS = 150;
	private static final int DELAY = 5;
	
	private ArrayList<GOval> balls;
	private ArrayList<Double> ballVx;
	private ArrayList<Double> ballVy;
	private RandomGenerator rg = new RandomGenerator();
	
	/* Here is a complicated example of using arrayLists. I have included it in the
	 * starter code files for those that are curious, or who just want to run the file
	 * to see the animation. It displays the use of an arrayList.
	 */
	public void run() {
		initBalls();
		while(true) {
			animateBalls();
			pause(DELAY);
		}
	}

	/* Animate one animation frame.*/
	private void animateBalls() {
		int size = balls.size();
		for(int i = 0; i < size; i++) {
			GOval ball = balls.get(i);
			checkForWalls(i, ball);
			ball.move(ballVx.get(i), ballVy.get(i));
			ball.setColor(rg.nextColor());
		}
	}
	
	/* Check for the ball hitting the wall. */
	private void checkForWalls(int index, GOval ball) {
		if(ball.getX() > getWidth() - SIZE) {
			reflectX(index);
			createBall(ball.getX() - SIZE, ball.getY(),
					-Math.abs(randomVelocity()), randomVelocity());
		}
		if (ball.getX() < 0) {
			reflectX(index);
			createBall(ball.getX() + SIZE, ball.getY(),
					Math.abs(randomVelocity()), randomVelocity());
		}
		if(ball.getY() > getHeight() - SIZE) {
			reflectY(index);
			createBall(ball.getX(), ball.getY() - SIZE,
					randomVelocity(), -Math.abs(randomVelocity()));
		}
		if (ball.getY() < 0) {
			reflectY(index);
			createBall(ball.getX(), ball.getY() + SIZE,
					randomVelocity(), Math.abs(randomVelocity()));
		}
	}

	/* Reflects a ball's Y-velocity. */
	private void reflectY(int i) {
		ballVy.set(i, -ballVy.get(i));
	}

	/* Reflects a ball's X-velocity. */
	private void reflectX(int i) {
		ballVx.set(i, -ballVx.get(i));
	}

	/* Initialize the arrayLists and the first ball. */
	private void initBalls() {
		balls = new ArrayList<GOval>();
		ballVx = new ArrayList<Double>();
		ballVy = new ArrayList<Double>();
		createBall(rg.nextDouble(0, getWidth() - SIZE),
				rg.nextDouble(0, getHeight()- SIZE),
				randomVelocity(),
				randomVelocity());
	}
	
	/* Return a random velocity. */
	private double randomVelocity() {
		return rg.nextDouble(0,1) > 0.5 ? rg.nextDouble(1, 3) : -rg.nextDouble(1, 3);
	}

	/* Create a ball with a random X,Y location and a random velocity. */
	private void createBall(double x, double y, double vx, double vy) {
		if (balls.size() >= MAX_BALLS) return;
		GOval ball = new GOval(x, y, SIZE, SIZE);
		ball.setFilled(true);
		ball.setColor(rg.nextColor());
		add(ball);
		balls.add(ball);
		ballVx.add(vx);
		ballVy.add(vy);
	}
}
