import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;

public class BouncingBall extends GraphicsProgram {
	
	public void run() {
		// Your code here...
	}

}
