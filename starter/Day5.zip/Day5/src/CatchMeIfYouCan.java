import acm.program.*;
import acm.graphics.*;
import acm.util.*;

import java.awt.Color;
import java.awt.event.*;

public class CatchMeIfYouCan extends GraphicsProgram {
	private static final double HIDDEN_SIZE = 60;
	private static final double DISTRACTOR_SIZE = 50;
	private static final double NUM_DISTRACTORS = 20;
	
	public void run() {
		// your code here
	}

}
