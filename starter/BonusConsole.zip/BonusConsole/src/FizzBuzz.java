import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class FizzBuzz extends ConsoleProgram {
	
	private static final int UPPER_LIMIT = 100;
	
	public void run() {
		
	}
}
