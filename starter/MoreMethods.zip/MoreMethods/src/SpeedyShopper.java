import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class SpeedyShopper extends ConsoleProgram {

	public void run() {
		println(calculatePrice(100.32, .25));
		println(calculatePrice(53.27, .15));
	}

	private double calculatePrice(double originalPrice, double percentOff) {
		return originalPrice * (1 - percentOff);
	}
}
