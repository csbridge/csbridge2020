import stanford.karel.*;

public class Midpoint extends SuperKarel {
	public void run() {
		// your code goes here...
	}
}

