import java.awt.Color;

import stanford.karel.*;

public class SquarePainter extends SuperKarel {
	public void run() {
		
	}
	
	
}

