import acm.graphics.GOval;


public class Ball {
	public GOval oval;
	public double vx;
	public double vy;
}
