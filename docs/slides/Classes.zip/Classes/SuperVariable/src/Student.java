

public class Student {
	
	public String name;
	
	public int age;
}