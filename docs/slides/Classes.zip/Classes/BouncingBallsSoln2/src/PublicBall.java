import acm.graphics.GOval;


public class PublicBall {
	public GOval oval;
	public double vx;
	public double vy;
}
