import acm.graphics.GOval;


public class Ball {
	private GOval oval;
	private double vx;
	private double vy;
	
	public GOval getOval() {
		return oval;
	}
	
	public void setOval(GOval oval) {
		this.oval = oval;
	}
	
	public double getVx() {
		return vx;
	}
	
	public void setVx(double vx) {
		this.vx = vx;
	}
	
	public double getVy() {
		return vy;
	}
	
	public void setVy(double vy) {
		this.vy = vy;
	}
	
}
