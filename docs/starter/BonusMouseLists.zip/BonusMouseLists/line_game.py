"""
File: line_game.py
-------------
A game where the user controls a dot with the mouse and must avoid having the dot
touch any black area on the screen.  The white "path" that scrolls down the screen is randomly generated.
"""

from graphics import Canvas
import math
import random
import time


# The amount of time we pause each iteration of the animation loop
DELAY = 0.01

# The diameter of the user's dot shape they navigate with
DOT_DIAMETER = 15

# The size (width/height) of a single "block" of the path that scrolls down the screen
PATH_BLOCK_SIZE = 50

# The size of the window
CANVAS_WIDTH = 300
CANVAS_HEIGHT = 700


def main():
    # Initialize the canvas
    canvas = Canvas(CANVAS_WIDTH, CANVAS_HEIGHT)
    canvas.set_canvas_title("Line Game")

    # TODO: your code here!

    canvas.mainloop()


if __name__ == '__main__':
    main()
