"""
File: hello_world.py
------------------
The classic
"""

def main():
    # Your code here
    # Delete the `pass` line before starting to write your own code
    pass

if __name__ == "__main__":
    main()