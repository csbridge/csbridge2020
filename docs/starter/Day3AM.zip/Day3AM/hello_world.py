"""
File: hello_world.py
------------------
Prints out the message "Hello, world" to the user.
"""


def main():
    # Your code here
    # Delete the `pass` line before starting to write your own code
    pass


if __name__ == "__main__":
    main()
