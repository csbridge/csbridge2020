"""
File: moon.py
------------------
Converts weight on earth into weight on the moon.
"""

def main():
    # Your code here
    # Delete the `pass` line before starting to write your own code
    pass

if __name__ == "__main__":
    main()