"""
File: running_sum.py
-------------------
This program reads in integers from the user
and then keeps outputting the sum of the entered values.
"""


def main():
    # Your code here
    # Delete the `pass` line before starting to write your own code
    pass


if __name__ == '__main__':
    main()
