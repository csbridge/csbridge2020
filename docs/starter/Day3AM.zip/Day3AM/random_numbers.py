"""
File: random_numbers.py
------------------
Prints 1,000 random numbers between 0 and 100
"""

import random

def main():
    # Your code here
    # Delete the `pass` line before starting to write your own code
    pass

if __name__ == "__main__":
    main()