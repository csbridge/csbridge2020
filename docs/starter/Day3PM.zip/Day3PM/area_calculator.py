"""
File: area_calculator.py
-------------------
This program can calculate the area of a circle with a radius that
is entered by the user.  It also prints out if the user has entered
an invalid (0 or negative) radius.
"""

# This line is needed to use the value of pi
import math


def main():
    # Your code here
    # Delete the `pass` line before starting to write your own code
    pass


if __name__ == '__main__':
    main()
