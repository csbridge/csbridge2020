"""
File: 8ball.py
-------------------
Simulates an eight ball and gives sage answers to
yes or no questions.
"""

# This is needed to generate random numbers
import random


def main():
    while True:
        input("Ask a yes or no question: ")

        # remember, this is a comment
        # BEGIN YOUR CODE

        # END YOUR CODE


if __name__ == '__main__':
    main()
