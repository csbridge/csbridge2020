"""
File: 8ball.py
-------------------
Simulates an eight ball and gives sage answers to
yes or no questions.
"""

def main():
    print("Welcome to the magic 8-ball.")

    while True:
        input("Ask a yes or no question: ")

        # remember, this is a comment
        # BEGIN YOUR CODE
        

        # END YOUR CODE

# call the function
if __name__ == '__main__':
    main()
