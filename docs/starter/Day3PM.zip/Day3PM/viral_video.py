"""
File: viral_video.py
-------------------
This program asks the user for a target number of video views
and a growth rate, and calculates how many view the video creator
will get over time and how many days it will take to get to the target
number of views.
"""


def main():
    # Your code here
    # Delete the `pass` line before starting to write your own code
    pass


if __name__ == "__main__":
    main()
