"""
CS Bridge 2020
The program captures data about animals, their diet and feeding times using dictionaries
Author: Ayca Tuzmen
"""

def main():
    pass



if __name__ == '__main__':
    main()