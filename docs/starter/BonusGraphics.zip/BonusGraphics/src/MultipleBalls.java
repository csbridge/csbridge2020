
import acm.graphics.*;     // GOval, GRect, etc.
import acm.program.*;      // GraphicsProgram
import acm.util.*;         // RandomGenerator
import java.awt.*;         // Color

public class MultipleBalls extends GraphicsProgram {
	
	public void run() {
		// your code here...
	}
	
}
