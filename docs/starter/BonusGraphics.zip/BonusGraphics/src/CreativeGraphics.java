import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;

public class CreativeGraphics extends GraphicsProgram {
	
	public void run() {
		// Your code here...
		// Anything you want!
	}

}
