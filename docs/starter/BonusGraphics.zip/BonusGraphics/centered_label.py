"""
File: centered_label.py
--------------------
This program draws centered text on the screen using a function that can
add any text to the center of the screen.
"""

from graphics import Canvas


def main():
    canvas = Canvas()
    canvas.set_canvas_title("Centered Label")
    draw_centered_label(canvas, "Coding Rocks!", "Courier", 40)
    canvas.mainloop()


# TODO: add the draw_centered_label function here!


if __name__ == '__main__':
    main()
