"""
File: fibonacci.py
--------------------
This program lists the terms in the Fibonacci sequence by using a function
that prints out fibonacci numbers up to a specified max number.
"""


def main():
    fibonacci(60)
    fibonacci(500)


# TODO: add the fibonacci function here!


if __name__ == '__main__':
    main()
