"""
File: creative_graphics.py
-------------------
This program creates miscellaneous art, including images and a bouncing ball.
"""

from graphics import Canvas

# Canvas size
CANVAS_WIDTH = 600
CANVAS_HEIGHT = 400


def main():
    canvas = Canvas(CANVAS_WIDTH, CANVAS_HEIGHT)
    canvas.set_canvas_title("Creative Graphics")

    # TODO: your code here! (Feel free to use karel.png in this project if you'd like, or add other images)

    canvas.mainloop()


if __name__ == "__main__":
    main()
