"""
File: bouncing_balls.py
-----------------------
This program animates two balls bouncing around the screen.  They bounce off
the walls and also off of each other.
"""

from graphics import Canvas
import random
import time

# The size of the balls
BALL_DIAMETER = 50

# The delay (in seconds) for the animation
DELAY = 0.01

# The bounds of the random x and y velocities (either + or -) for the balls
VELOCITY_MIN = 3
VELOCITY_MAX = 6


def main():
    canvas = Canvas()
    canvas.set_canvas_title("Bouncing Balls")

    # TODO: your code here (consider using functions with multiple return values!)

    canvas.mainloop()


if __name__ == "__main__":
    main()
