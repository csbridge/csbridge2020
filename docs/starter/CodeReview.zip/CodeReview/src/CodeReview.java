import acm.graphics.*;
import acm.program.*;
import java.awt.*;

public class CodeReview extends GraphicsProgram {

    private static final int SUN_DIAMETER = 50;
    private static final int MAX_FRAME_YELLOW = 30;
    private static final int MAX_FRAME_ORANGE = 50;
    private static final int DELAY = 50;

    public void run() {
        displayMessage("Once upon a time...");
        
        GRect s2 = new GRect(getWidth(), getHeight() / 2);
        s2.setFilled(true);
        s2.setColor(Color.BLUE);
        add(s2);
        GOval s = new GOval(SUN_DIAMETER, SUN_DIAMETER);
        s.setFilled(true);
        s.setColor(Color.YELLOW);
        double sunX = getWidth() / 2 - s.getWidth() / 2;
        double sunY = getHeight() / 4 - s.getHeight() / 2;
        add(s, sunX, sunY);
        GRect earth = new GRect(0, getHeight() / 2, getWidth(), getHeight() / 2);
        earth.setFilled(true);
        earth.setColor(Color.GREEN);
        add(earth);


        int frame = 0;
        while (s.getY() < earth.getY()) {
            getSunColor(frame, s);
            pause(DELAY);
            frame++;
        }
        
        displayMessage("The end");
    }

    private void getSunColor(int frame, GOval sun) {
        if (frame <= MAX_FRAME_YELLOW) {
            sun.setColor(Color.yellow);
        } else if (frame <= MAX_FRAME_ORANGE) {
            sun.setColor(Color.orange);
        } else {
            sun.setColor(Color.RED);
        }
        
        sun.move(0, 2);
    }

    private void displayMessage(String message) {
        // Add a black "background"
        GRect background = new GRect(getWidth(), getHeight());
        background.setFilled(true);
        add(background);

        // Create the centered white message
        GLabel label = new GLabel(message);
        label.setColor(Color.WHITE);
        label.setFont("Papyrus-40");
        double xLocation = getWidth() / 2 - label.getWidth() / 2;
        double yLocation = getHeight() / 2 + label.getAscent() / 2;
        add(label, xLocation, yLocation);

        pause(2000);
        remove(label);
        remove(background);
    }

}