"""
File: making_tracks.py
-------------------
This program draws a track wherever the user clicks the mouse.
"""

from graphics import Canvas


def main():
    canvas = Canvas()
    canvas.set_canvas_title("Making Tracks")

    # TODO: your code here!

    canvas.mainloop()


if __name__ == '__main__':
    main()
