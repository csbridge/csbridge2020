import stanford.karel.*;

public class BuildCharlesBridge extends SuperKarel {
	
	public void run() {
		// your code here
	}

}
