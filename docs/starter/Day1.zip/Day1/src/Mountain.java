import stanford.karel.*;

public class Mountain extends SuperKarel {
	
	public void run() {
		// your code goes here...
	}

}
