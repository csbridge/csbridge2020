import stanford.karel.*;

public class BanishWinter extends SuperKarel {

	public void run() {
		for(int i = 0; i < 4; i++) {
			moveToTree();
			fixTree();
		}
		
	}

	/*
	 * fixTree()
	 * Climbs to the top of one tree, adds leaves, and descends other side of tree.
	 */
	private void fixTree() {
		turnLeft();
		climbTree();
		turnRight();
		placeLeaves();
		turnRight();
		moveToWall();
		turnLeft();
	}
	
	/*
	 * moveToTree()
	 * Wrapper for moveToWall - moves until Karel is facing and adjacent to a tree.
	 */
	public void moveToTree() {
		moveToWall();
	}
	
	/*
	 * moveToWall()
	 * Moves in a straight line up to a wall.
	 */
	public void moveToWall() {
		while(frontIsClear()) {
			move();
		}
	}

	/*
	 * climbTree()
	 * Moves up to and one space past the end of a wall/tree trunk.
	 */
	public void climbTree() {
		while(rightIsBlocked()) {
			move();
		}
	}
	
	/*
	 * placeLeaves()
	 * Adds four leaves in the required pattern to the top of a tree.
	 */
	public void placeLeaves() {
		for(int i = 0; i < 4; i++) {
			putBeeper();
			move();
			turnLeft();
		}
		move();
	}
}
