import stanford.karel.*;

/*
 * Program: Banish Winter
 * ----------------------
 * Karel should add leaves to the top of each tree in the world
 * from left to right to spruce up campus for the spring.
 * The world is of width 9, but it may have any number of trees
 * of any height.
 */
public class BanishWinter extends SuperKarel {

    public void run() {
        for (int i = 0; i < 8; i++) {
            if (frontIsClear()) {
                move();
            } else {
                fixTree();
            }
        }
    }

    /*
     * Method: fixTree
     * ---------------
     * Climbs to the top of one tree, adds leaves, and descends 
     * other side of tree.  When this method is called, Karel is assumed to
     * be facing east at the bottom of the tree to fix, and when the method
     * is done Karel will be facing east immediately after the tree which has
     * now been fixed.
     */
    private void fixTree() {
        turnLeft();
        climbTree();
        turnRight();
        placeLeaves();
        turnRight();
        moveToBottom();
        turnLeft();
    }
    
    /*
     * Method: moveToBottom
     * --------------------
     * Moves in a straight line in the direction Karel is facing up to a wall.
     * Used for moving from the top to the bottom of a tree.
     */
    public void moveToBottom() {
        while (frontIsClear()) {
            move();
        }
    }

    /*
     * Method: climbTree()
     * -------------------
     * Moves up to and one space past the end of a wall/tree trunk.
     */
    public void climbTree() {
        while (rightIsBlocked()) {
            move();
        }
    }
    
    /*
     * Method: placeLeaves()
     * ---------------------
     * Adds four leaves in the required pattern to the top of a tree.
     */
    public void placeLeaves() {
        for (int i = 0; i < 4; i++) {
            putBeeper();
            move();
            turnLeft();
        }
        move();
    }
}