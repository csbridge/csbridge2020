import stanford.karel.*;

public class BuildEfes extends SuperKarel {
	
	public void run() {
		// your code here
	}

}
