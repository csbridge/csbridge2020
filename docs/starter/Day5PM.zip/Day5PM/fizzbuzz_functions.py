"""
File: fizzbuzz_functions.py
--------------------
This program plays the game fizzbuzz up to a given number entered by the user.
"""


def main():
    # TODO: your code here (remove the 'pass' when you start)
    pass


def fizzbuzz(n):
    """
    Plays the fizzbuzz game up to and including n.  It prints out numbers from 1 to n,
    except if the number is divisible by 3, it instead prints "Fizz", if the number
    is divisible by 5, it instead prints "Buzz", and if it is both, instead it prints "FizzBuzz".
    This function returns the count of numbers that were replaced.
    """
    # TODO: your code here (remove the 'pass' when you start)
    pass


if __name__ == "__main__":
    main()
