"""
File: mad_methods.py
--------------------
This program prints out the maximum of three numbers.
"""

def mad_max(x, y, z):
    """
    Takes in three inputs (x, y, and z) and returns the largest of the three.
    """
    # TODO: Delete the `return -1` line before starting to write your own code.
    return -1

def main():
    print("The max of 4, 5, and 6 is:", mad_max(4, 5, 6))
    print("The max of -4, 4, and 0 is:", mad_max(-4, 4, 0))
    print("The max of 3, 2, and 1 is:", mad_max(3, 2, 1))
    print("The max of 0, 0, and 0 is:", mad_max(0, 0, 0))

if __name__ == "__main__":
    main()