"""
File: fizzbuzz.py
------------------
Counting, except multiples of 3 are replaced with "Fizz", multiples
of 5 are replaced with "Buzz", and multiples of 3 and 5 are replaced
with "Fizzbuzz"
"""

# You should define a function called fizzbuzz here

# End fizzbuzz function

def main():
    # Your code here
    # Delete the `pass` line before starting to write your own code
    pass

if __name__ == "__main__":
    main()
