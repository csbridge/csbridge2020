"""
File: programming_is_awesome.py
-------------------
Shows the awesomeness of graphics.
"""

from graphics import Canvas

def main():
    """
    You should write your code between the two lines written
    already that set up the canvas.
    You should replace this comment with a better, more descriptive one.
    """
    canvas = Canvas()
    canvas.set_canvas_title("Programming is Awesome")

    # TODO: your code here

    canvas.mainloop()

# call the function
if __name__ == '__main__':
    main()
