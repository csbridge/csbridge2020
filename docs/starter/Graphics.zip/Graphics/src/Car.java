import acm.graphics.*;
import acm.program.*;
import acm.util.*;
import java.awt.*;

/* This program draws a car on the canvas with a yellow
 * background.  The car should have a body, 2 wheels,
 * and a windshield.
 */
public class Car extends GraphicsProgram {
    
    public void run() {
        // our code here
    }

}