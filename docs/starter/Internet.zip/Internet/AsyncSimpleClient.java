import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * AsyncSimpleClient
 * @author nicktroccoli
 *
 * This class acts as a wrapper around SimpleClient.  It reimplements makeRequest
 * to accept the same parameters but not return anything, and instead be asynchronous.
 */
public class AsyncSimpleClient implements Runnable {
    
    // The number of threads alive at one time (each thread sends a request)
    private static final int N_THREADS = 10;
    
    // The thread pool spawning threads
    private static ExecutorService threadPool = Executors.newFixedThreadPool(N_THREADS);
    
    // An instance of this class has a host and request it should send on its thread
    private String host;
    private Request request;
    
    // Initializes an instance with the specified host and the specified request to send
    private AsyncSimpleClient(String host, Request request) {
        this.host = host;
        this.request = request;
    }
    
    // Running this thread sends its request to the specified host
    public void run() {
        try {
            SimpleClient.makeRequest(host, request);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * This function asynchronously sends the given request to the given host.
     * @param hostname the host to send to
     * @param requestToMake the request to send
     */
    public static void makeRequest(String hostname, Request requestToMake) {
        threadPool.execute(new AsyncSimpleClient(hostname, requestToMake));
    }
}
