import java.awt.*;
import java.util.ArrayList;
import java.util.StringTokenizer;

/**
 * PlayerInfo
 * @author nicktroccoli
 * This class stores information about a single player, including
 * the player's name, and the location and color of their piece onscreen.
 */
public class PlayerInfo {
    
    // The name of the player
    private String name;
    
    // The coordinates and color of the player on screen
    private int x;
    private int y;
    private Color color;
    
    // Create new info for a player, specifying the color of their piece
    public PlayerInfo(String name, int x, int y, Color color) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.color = color;
    }
    
    // Create new info for a player, specifying the string name of their color
    public PlayerInfo(String name, int x, int y, String colorAsString) {
        this(name, x, y, PlayerInfo.stringToColor(colorAsString));
    }
    
    // Create new info for a player from the given string that was generated from toString()
    public PlayerInfo(String serializedString) {
        StringTokenizer tokenizer = new StringTokenizer(serializedString, ",");
        name = tokenizer.nextToken();
        x = Integer.parseInt(tokenizer.nextToken());
        y = Integer.parseInt(tokenizer.nextToken());
        color = stringToColor(tokenizer.nextToken());
    }
    
    public String toString() {
        return name + "," + x + "," + y + "," + getColorAsString();
    }
    
    /* Serializing / Deserializing */
    public static String serializePlayerInfos(ArrayList<PlayerInfo> infos) {
        String result = "";
        for (int i = 0; i < infos.size(); i++) {
            result += infos.get(i).toString();
            if (i < infos.size() - 1) {
                result += "|";
            }
        }
        
        return result;
    }
    
    public static ArrayList<PlayerInfo> deserializePlayerInfos(String infosString) {
        ArrayList<PlayerInfo> infos = new ArrayList<PlayerInfo>();
        StringTokenizer linesTokenizer = new StringTokenizer(infosString, "|");
        while (linesTokenizer.hasMoreTokens()) {
            infos.add(new PlayerInfo(linesTokenizer.nextToken()));
        }
        return infos;
    }
    
    /* functions for translating between strings and colors */
    
    private static Color stringToColor(String color) {
        if (color.equalsIgnoreCase("red")) {
            return Color.RED;
        } else if (color.equalsIgnoreCase("orange")) {
            return Color.orange;
        } else if (color.equalsIgnoreCase("yellow")) {
            return Color.yellow;
        } else if (color.equalsIgnoreCase("green")) {
            return Color.GREEN;
        } else if (color.equalsIgnoreCase("blue")) {
            return Color.blue;
        } else if (color.equalsIgnoreCase("pink")) {
            return Color.pink;
        }
        
        return Color.black;
    }
    
    private static String colorToString(Color color) {
        if (color == Color.red) {
            return "red";
        } else if (color == Color.orange) {
            return "orange";
        } else if (color == Color.YELLOW) {
            return "yellow";
        } else if (color == Color.GREEN) {
            return "green";
        } else if (color == Color.blue) {
            return "blue";
        } else if (color == Color.pink) {
            return "pink";
        } else return "black";
    }
    
    /* Getters */
    
    public String getName() {
        return name;
    }
    
    public int getX() {
        return x;
    }
    
    public int getY() {
        return y;
    }
    
    public Color getColor() {
        return color;
    }
    
    public String getColorAsString() {
        return colorToString(color);
    }
    
    /* Setters */
    
    public void setName(String newName) {
        name = newName;
    }
    
    public void setX(int newX) {
        x = newX;
    }
    
    public void setY(int newY) {
        y = newY;
    }
    
    public void setColor(Color newColor) {
        color = newColor;
    }
    
    public void setColor(String newColorName) {
        color = stringToColor(newColorName);
    }

}
