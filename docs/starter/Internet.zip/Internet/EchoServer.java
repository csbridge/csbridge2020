import acm.program.*;

/*
 * This program is a server that responds to requests by
 * sending back how many characters long its command was.
 */
public class EchoServer extends ConsoleProgram implements SimpleServerListener {

	private SimpleServer server = new SimpleServer(this, 8090);
	
	public void run() {
		server.start();
		println("Starting server...");
	}

	public String requestMade(Request request) {
		String cmd = request.getCommand();
		int cmdLength = cmd.length();
		return "Your command was " + cmdLength + " chars long.";
	}
	
}
