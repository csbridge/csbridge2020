import java.util.*;
import acm.program.*;


public class MyChatServer extends ConsoleProgram implements SimpleServerListener {

    private static final int PORT = 8080;

    private SimpleServer server = null;

    /* The server database is an ArrayList of Strings */
    private ArrayList<String> messages = new ArrayList<String>();

    public void run() {
        println("Starting server on port " + PORT + "...");
        server = new SimpleServer(this, PORT);
        server.start();
    }

    public String requestMade(Request request) {
        // TODO: implement this!
        return "Error: not implemented";
    }
}
