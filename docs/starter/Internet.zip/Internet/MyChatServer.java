import java.util.*;
import acm.program.*;


public class MyChatServer extends ConsoleProgram implements SimpleServerListener {

    private static final int PORT = 8000;

    private SimpleServer server = null;

    /* The server database is an ArrayList of Strings */
    private ArrayList<String> messages = new ArrayList<String>();

    public void run() {
        println("Starting server on port " + PORT + "...");
        server = new SimpleServer(this, PORT);
        server.start();
    }

    public String requestMade(Request request) {
        String command = request.getCommand();
        if (command.equals("newMsg")) {
            // Handle the user sending a new message
            String message = request.getParam("msg");
            messages.add(message);
            return "OK";
        } else if (command.equals("getMsgs")) {
            int index = Integer.parseInt(request.getParam("index"));
            List<String> sublist = messages.subList(index, messages.size());
            return sublist.toString();
        } else {
            return "Error: unknown command";
        }
    }
}
