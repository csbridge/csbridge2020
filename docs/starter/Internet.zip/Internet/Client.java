import acm.io.*;
import acm.program.*;
import java.awt.event.*;
import java.io.*;
import acm.graphics.*;
import java.util.*;

/**
 * Client
 * @author nicktroccoli
 * This program displays one oval on the screen per player, and updates
 * the current player's oval with the mouse, and the other players' locations
 * via a Server program at the specified host address.  Once the program starts,
 * it asks the player for their name and preferred oval color, and then registers
 * them with the server.  Then it moves their circle and updates the server when
 * the mouse is moved, and periodically pings the server for any updates of the
 * other players' pieces.
 */
public class Client extends GraphicsProgram {

    private static final String HOST = "http://e1ca2069.ngrok.io";
    private static final int CIRCLE_RADIUS = 50;
    private static final int DELAY = 50;
    
    // Information for the current player
    private GOval ownPlayerOval;
    private PlayerInfo playerInfo;

    public void run() {
        IODialog dialog = getDialog();
        String playerName = dialog.readLine("Enter player name");
        String colorName = dialog.readLine("Enter player color");
        setUpPlayer(playerName, colorName);

        addMouseListeners();

        pollForOtherPlayerUpdates();    // infinite loop
    }

    // Sets up the graphic for the player's piece, and registers with the server
    private void setUpPlayer(String nameOfPlayer, String colorOfPlayer) {
        // Create player's shape
        playerInfo = new PlayerInfo(nameOfPlayer, 0, 0, colorOfPlayer);
        ownPlayerOval = new GOval(getWidth() / 2 - CIRCLE_RADIUS, getHeight() / 2 - CIRCLE_RADIUS, 
                2 * CIRCLE_RADIUS, 2 * CIRCLE_RADIUS);
        ownPlayerOval.setFilled(true);
        ownPlayerOval.setColor(playerInfo.getColor());
        add(ownPlayerOval);

        // Make a synchronous request to ensure the game starts after the request is made
        Request registerRequest = new Request("registerPlayer");
        registerRequest.addParam("player", nameOfPlayer);
        registerRequest.addParam("color", colorOfPlayer);
        try {
            SimpleClient.makeRequest(HOST, registerRequest);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Infinite loops, requesting updated information about all players,
     * and updating the onscreen graphics accordingly.
     */
    private void pollForOtherPlayerUpdates() {
        // Store and update the other player locations
        HashMap<String, GOval> otherPlayerOvals = new HashMap<String, GOval>();
        
        while (true) {
            Request r = new Request("getInfo");

            try {
                String response = SimpleClient.makeRequest(HOST, r);
                println(playerInfo.getName() + " received update [" + response + "]");
                ArrayList<PlayerInfo> allPlayerInfos = PlayerInfo.deserializePlayerInfos(response);
                
                // Update the screen with the new info
                for (PlayerInfo currPlayerInfo : allPlayerInfos) {

                    // Skip ourselves
                    if (currPlayerInfo.getName().equals(playerInfo.getName())) continue;

                    // If we have this player onscreen already, update the oval location
                    if (otherPlayerOvals.containsKey(currPlayerInfo.getName())) {
                        otherPlayerOvals.get(currPlayerInfo.getName()).setLocation(currPlayerInfo.getX(), 
                                currPlayerInfo.getY());
                    } else {
                        // Otherwise, make a new oval for this player
                        GOval newPlayerOval = new GOval(currPlayerInfo.getX(), currPlayerInfo.getY(), 
                                2 * CIRCLE_RADIUS, 2 * CIRCLE_RADIUS);
                        newPlayerOval.setFilled(true);
                        newPlayerOval.setColor(currPlayerInfo.getColor());
                        otherPlayerOvals.put(currPlayerInfo.getName(), newPlayerOval);
                        add(newPlayerOval);
                    }
                }
            } catch (IOException e) {
                println("\tCould not send message.");
            }

            pause(DELAY);
        }
    }

    // Update this player's piece location, and update the server as well
    public void mouseMoved(MouseEvent e) {
        ownPlayerOval.setLocation(e.getX(), e.getY());
        Request r = new Request("updateLocation");
        r.addParam("player", playerInfo.getName());
        r.addParam("x", "" + e.getX());
        r.addParam("y", "" + e.getY());
        r.addParam("color", playerInfo.getColorAsString());
        AsyncSimpleClient.makeRequest(HOST, r);
    }
}
