import acm.program.*;
import java.io.*;

/*
 * This program lets the user send messages to an Echo server
 * and prints out the response.
 */
public class EchoClient extends ConsoleProgram {
    
    private static final String HOST = "http://localhost:8090";
    
    public void run() {
        println("Enter a command to send (or ENTER to quit): ");
        String commmand = readLine("> ");
        while (commmand.length() != 0) {

            try {
                // 1. construct a new request
                Request example = new Request(commmand);

                // 3. send the request to a computer on the internet
                String result = SimpleClient.makeRequest(HOST, example);
                
                println("Response: " + result);

            } catch(IOException e) {
                // The internet is a fast and wild world my friend
                println("An error occurred :(");
            }

            commmand = readLine("> ");
        }
    }
}
