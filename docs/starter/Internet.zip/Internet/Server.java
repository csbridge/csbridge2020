import java.util.*;
import acm.program.*;

/**
 * Server
 * @author nicktroccoli
 * This server stores information about each player in the game.  It can handle
 * the following requests:
 * 
 * registerPlayer: with player and color parameters, adds a new player with the given name and player color.
 * updateLocation: with player, x and y parameters, updates that player's location to be at (x, y)
 * getInfo: sends back a string representation of the information about all players.  The response
 *      is serialized using PlayerLocationSerializer, which can also deserialize it into a map of player info.
 */
public class Server extends ConsoleProgram implements SimpleServerListener {

    private SimpleServer server = new SimpleServer(this, 8000);
    
    // A map containing information about each player in the game
    private HashMap<String, PlayerInfo> playerInfoMap;

    public void run() {
        playerInfoMap = new HashMap<String, PlayerInfo>();
        server.start();
        println("Starting server...");
    }

    public String requestMade(Request request) {
        String cmd = request.getCommand();
        
        // Update Location of the player
        if (cmd.equals("updateLocation")) {
            int x = Integer.parseInt(request.getParam("x"));
            int y = Integer.parseInt(request.getParam("y"));
            String playerName = request.getParam("player");

            // update the map
            PlayerInfo newInfo = playerInfoMap.get(playerName);
            newInfo.setX(x);
            newInfo.setY(y);
            playerInfoMap.put(playerName, newInfo);
            return "OK";
            
        // Get info for all players
        } else if (cmd.equals("getInfo")) {
            return PlayerInfo.serializePlayerInfos(new ArrayList<PlayerInfo>(playerInfoMap.values()));
            
        // Register a new player with the given color
        } else if (cmd.equals("registerPlayer")) {
            String playerName = request.getParam("player");
            String colorName = request.getParam("color");
            PlayerInfo newInfo = new PlayerInfo(playerName, 0, 0, colorName);
            playerInfoMap.put(playerName, newInfo);
            return "OK";
        } else {
            println("Invalid request type [" + cmd + "]");
            return "Invalid request type";
        }
    }

}
