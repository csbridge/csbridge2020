/*
 * File: MyWhackAMole.java
 * -----------------
 * This program plays the game Whack-A-Mole.  Every 1/2 second, a mole appears
 * somewhere random on the screen.  If the user clicks a mole, the mole disappears.
 */
import acm.graphics.*;
import acm.program.*;
import acm.util.*;
import java.awt.*;
import java.awt.event.*;

public class WhackAMole extends GraphicsProgram {
	
	// Pause in between adding moles
	private static final double PAUSE_TIME = 500;
	
}
