/*
 * File: MouseTracker.java
 * -----------------
 * This is a program displays a GRect that follows
 * the mouse around the screen.
 * 
 * This program requires an instance variable to store the GRect so
 * its location can be changed in the mouseMoved method. 
 */

import acm.program.*;
import acm.graphics.*;
import java.awt.*;
import java.awt.event.*;

public class MouseTracker extends GraphicsProgram {
	
    private static final int SQUARE_SIZE = 50;

}
