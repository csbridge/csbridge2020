/*
 * File: Doodler.java
 * -----------------
 * This is a program that lets the user "doodle" by drawing
 * GRects along the path where the user clicks and drags the mouse.
 */

import acm.graphics.*;
import acm.program.*;
import acm.util.*;
import java.awt.*;
import java.awt.event.*;

public class Doodler extends GraphicsProgram {	
	
	private static final int SQUARE_SIZE = 10;

}




