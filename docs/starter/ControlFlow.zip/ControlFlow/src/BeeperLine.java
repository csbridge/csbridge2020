import stanford.karel.*;

/**
 * Program: BeeperLine
 * -------------------
 * Fill the first row with beepers. Assumes that Karel starts out in
 * the bottom left corner of the screen, facing east.
 */
public class BeeperLine extends SuperKarel {
	
	public void run() {
		// our code here
	}
}