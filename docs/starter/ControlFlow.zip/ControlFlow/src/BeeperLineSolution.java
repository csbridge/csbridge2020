import stanford.karel.*;

/**
 * Program: BeeperLine
 * -------------------
 * Fill the first row with beepers. Assumes that Karel starts out in
 * the bottom left corner of the screen, facing east.
 */
public class BeeperLineSolution extends SuperKarel {
	
	public void run() {
		while(frontIsClear()) {
			putBeeper();
			move();
		}
		/* This line is necessary to place the final beeper. The number
		 * of times Karel moves is one less than the number of times karel
		 * places a beeper (if the world is five squares wide, we place
		 * 5 beepers but only move 4 times).
		 */
		putBeeper();
	}
}