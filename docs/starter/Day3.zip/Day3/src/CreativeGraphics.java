import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;
import java.awt.*;

public class CreativeGraphics extends GraphicsProgram {
	
	public void run() {
		// Your code here...
		// Anything you want!
	}

}
