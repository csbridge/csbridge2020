import acm.graphics.*;
import acm.program.*;
import acm.util.*;
import java.awt.*;

public class CreativeGraphics extends GraphicsProgram {
	
	public void run() {
		// Your code here...
		// Anything you want!
	}

}
