import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;
import java.awt.*;

/**
 * Bouncing Ball
 * --------------
 *  Bounces a ball around the screen.
 */
public class BouncingBall extends GraphicsProgram {
	
	public void run() {
		// Your code here...
	}

}
