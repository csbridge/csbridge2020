import acm.graphics.*;
import acm.program.*;
import acm.util.*;
import java.awt.*;

/**
 * Bouncing Ball
 * --------------
 *  Bounces a ball around the screen.
 */
public class BouncingBall extends GraphicsProgram {
	
	public void run() {
		// Your code here...
	}

}
