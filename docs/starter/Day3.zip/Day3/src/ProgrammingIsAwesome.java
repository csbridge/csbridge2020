import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;
import java.awt.*;

/**
 * Programming Is Awesome
 * --------------
 * Shows the awesomeness of graphics.
 */
public class ProgrammingIsAwesome extends GraphicsProgram {
	
	public void run() {
		// Your code here...
	}

}
