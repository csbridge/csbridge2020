import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;
import java.awt.*;

/**
 * Random Circles
 * --------------
 * Draws 10 random circles such that each circle is on the screen.
 */
public class RandomCircles extends GraphicsProgram {
	
	private static final int NUM_CIRCLES = 10;
	private RandomGenerator rgen = new RandomGenerator();
	
	public void run() {
		// your code here...
		
	}
}
