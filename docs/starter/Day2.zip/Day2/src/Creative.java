import acm.program.*;
import acm.util.*;

/**
 * Creative
 * -----
 * Make any console program you like!
 */
public class Creative extends ConsoleProgram {

	public void run() {
		// your code here...
	}

}
