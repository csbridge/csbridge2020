import acm.program.*;
import acm.util.*;

/**
 * Favorite Number
 * -----
 * A user tries to guess your favorite number
 */
public class FavoriteNumber extends ConsoleProgram {

	// change this to be your favorite number
	private static final int FAVORITE_NUMBER = 0;
	
	public void run() {
		// your code here..
	}

}
