import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

/**
 * Moon
 * -----
 * Converts weight on earth into weight on the mooon.
 */
public class Moon extends ConsoleProgram {

	public void run() {
		// your code here...
	}

}
