import acm.program.*;
import acm.util.*;

/**
 * Moon
 * -----
 * Converts weight on earth into weight on the moon.
 */
public class Moon extends ConsoleProgram {

	public void run() {
		// your code here...
	}

}
