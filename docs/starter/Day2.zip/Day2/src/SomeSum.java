import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

/**
 * SomeSum
 * -----
 * Write a program that reads in 10 integers 
 * from the user and then outputs the sum of the entered values
 */
public class SomeSum extends ConsoleProgram {

	public void run() {
		// your code here...
	}

}
