import acm.program.*;
import acm.util.*;

/**
 * Hello World
 * -----
 * The classic
 */
public class HelloWorld extends ConsoleProgram {

	public void run() {
		// your code here
	}

}
