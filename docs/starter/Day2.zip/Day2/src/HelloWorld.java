import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

/**
 * Hello World
 * -----
 * The classic
 */
public class HelloWorld extends ConsoleProgram {

	public void run() {
		// your code here
	}

}
