import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.ArrayList;


public class ClickNPause extends GraphicsProgram {
	/** Width and height of application window in pixels */
    public static int APPLICATION_WIDTH = 600;
    public static int APPLICATION_HEIGHT = 400;
    
    /** Animation loop delay **/
    public static int DELAY = 50;
    
	public void run() {
		/* YOUR CODE HERE */
	}
}
