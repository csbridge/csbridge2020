import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class Conversion extends ConsoleProgram {
	
	private static final double CM_PER_INCHES = 2.54;
	
	public void run() {
	
	}
}
