"""
File: number_grid.py
--------------------
This program draws a centered number grid using squares and labels.
It does this using a function draw_number_grid that can draw a centered
number grid of a given dimension with the specified constants below.
"""

from graphics import Canvas

# The size of the canvas
CANVAS_WIDTH = 400
CANVAS_HEIGHT = 400

# The dimensions and spacing for the number boxes
BOX_SIZE = 50
BOX_GAP = 5

# Font information for the number labels inside each box
TEXT_FONT_NAME = "Helvetica"
TEXT_FONT_SIZE = 30


def main():
    canvas = Canvas(CANVAS_WIDTH, CANVAS_HEIGHT)
    canvas.set_canvas_title("Number Grid")

    # TODO: your code here

    canvas.mainloop()


if __name__ == '__main__':
    main()
