import acm.graphics.*;
import acm.program.*;
import java.awt.*;

public class ShortFilm extends GraphicsProgram {

	public void run() {
		// animate a movie!
	}

}