import acm.graphics.*;
import acm.program.*;
import java.awt.*;

/**
 * Warning: This is an extension! You should only do it if you finish
 * Illusions1.
 */
public class Illusion2 extends GraphicsProgram {
	
	public static final int APPLICATION_WIDTH = 800;
	public static final int APPLICATION_HEIGHT = 520;
	
	private static final int ROW_HEIGHT = 50;
	private static final int NUM_ROWS = 10;
	
	public void run() {
		//your code here...
	}
}
