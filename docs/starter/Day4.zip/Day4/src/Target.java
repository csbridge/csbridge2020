import acm.graphics.*;
import acm.program.*;
import java.awt.*;

public class Target extends GraphicsProgram {

	private static final int BIG_CIRCLE_RADIUS = 150;
	private static final int MEDIUM_CIRCLE_RADIUS = 100;
	private static final int SMALL_CIRCLE_RADIUS = 50;
	
	public void run() {
		// your code here...
		// make sure to use methods!
	}

}