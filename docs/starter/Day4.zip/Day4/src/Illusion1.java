import acm.graphics.*;
import acm.program.*;
import java.awt.*;

public class Illusion1 extends GraphicsProgram {
	
	/* These constants tell the graphics program how big to be.
	 * You can ignore them. */
	public static final int APPLICATION_WIDTH = 540;
	public static final int APPLICATION_HEIGHT = 560;
	
	/* The size of each dimension of the square. Use this!*/
	private static final int SIZE = 100;
	
	/* The space between two squares. Use this!*/
	private static final int GAP = 10;
	
	public void run() {
		// your code here.
	}
	
}
