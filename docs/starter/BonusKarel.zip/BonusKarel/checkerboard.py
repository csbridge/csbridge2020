from karel.stanfordkarel import *

"""
File: checkerboard.py
------------------------------
At present, this file does nothing. Your job is to have Karel fill the world
with a checker pattern of beepers. You should make sure
that your program works for all of the worlds that meet the requirements
given in the problem.
"""


def main():
    pass


# There is no need to edit code beyond this point

if __name__ == "__main__":
    run_karel_program()
