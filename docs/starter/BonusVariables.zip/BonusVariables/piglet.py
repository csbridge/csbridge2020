"""
File: piglet.py
--------------------
This program plays the 1-player dice game "Piglet". Each turn,
the player rolls a die - if it's a 1, then the game is over and
they get a score of 0. Otherwise, the value is added to their
total and the player chooses whether or not to roll again. The
player tries to get the highest score possible.
"""

# This is needed for dice rolls.  Don't remove this!
import random


def main():
    # Your code here
    # Delete the `pass` line before starting to write your own code
    pass


if __name__ == '__main__':
    main()
