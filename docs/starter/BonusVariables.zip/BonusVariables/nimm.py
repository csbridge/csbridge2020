"""
File: nimm.py
-------------------
This program plays the ancient game of nimm.  2 Players
alternate taking 1 or 2 stones from the middle until there are zero left.
The last player to take a stone loses.
"""


def main():
    # Your code here
    # Delete the `pass` line before starting to write your own code
    pass


if __name__ == '__main__':
    main()
