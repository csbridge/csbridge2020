"""
File: conversion.py
--------------------
This program repeatedly asks the user to enter values in centimeters,
and converts these values to inches.  The program terminates when
the user enters -1 for the number of centimeters.
"""


def main():
    # Your code here!  Delete the `pass` line before starting to write your own code.
    pass


if __name__ == '__main__':
    main()
