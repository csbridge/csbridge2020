"""
File: hailstone.py
-------------------
This program generates the hailstone sequence for the number
a user enters.  Specifically, at each step, if n is even, 
divide it by two. If n is odd, multiply it by three and add one. 
Continue this process until n is equal to one.  This program
prints out the number at each step.
"""


def main():
    # Your code here
    # Delete the `pass` line before starting to write your own code
    pass


if __name__ == '__main__':
    main()
