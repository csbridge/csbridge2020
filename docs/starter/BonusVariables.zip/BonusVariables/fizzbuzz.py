"""
File: fizzbuzz.py
--------------------
This program prints out the numbers from 1 to 100, with some
special rules.  for multiples of three it prints “Fizz” 
instead of the number and for multiples of five it prints
“Buzz” instead of the number. For numbers that are multiples 
of both three and five, it prints “FizzBuzz” instead of the number.
"""


def main():
    # Your code here
    # Delete the `pass` line before starting to write your own code
    pass


if __name__ == '__main__':
    main()
