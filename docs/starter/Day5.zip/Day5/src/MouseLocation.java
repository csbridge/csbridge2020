/*
 * File: MouseLocation.java
 * -----------------------------
 * Output the location of the mouse to the screen
 */

import java.awt.event.*;
import acm.graphics.*;
import acm.program.*;

public class MouseLocation extends GraphicsProgram {

	public void run() {	
		// your code here
	}

}
