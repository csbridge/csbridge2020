"""
File: is_ascending.py
-------------------
This program prompts the user for numbers until they enter -1, and then
prints out the numbers and whether or not those numbers are in ascending order.
"""


def main():
    # TODO: your code here! (remove the pass when you start)
    pass


if __name__ == '__main__':
    main()
