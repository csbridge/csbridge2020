"""
File: sorted_numbers.py
-------------------
This program prompts the user for 10 numbers, and then
prints out those numbers in sorted order.
"""


def main():
    # TODO: your code here! (remove the pass when you start)
    pass


if __name__ == '__main__':
    main()
