from karel.stanfordkarel import *

"""
File: step_up.py
------------------------
Your first example Karel program. Have Karel pick up the beeper in front
of it and place it on top of the ledge.
(This is a comment. Your computer will ignore it.)
"""


def main():
    """
    When you start your program, this code will be executed.
    """
    pass


# There is no need to edit code beyond this point

if __name__ == "__main__":
    run_karel_program()
