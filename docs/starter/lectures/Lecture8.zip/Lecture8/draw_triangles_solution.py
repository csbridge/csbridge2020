"""
File: draw_triangles_solution.py
--------------------
This program draws triangles on the canvas using a function that can draw 1 triangle.
"""

from graphics import Canvas


def main():
    canvas = Canvas()
    canvas.set_canvas_title("Draw Triangles")

    draw_triangle(canvas, 0, 0, 300, 100, 20, 100)
    draw_triangle(canvas, 300, 100, 50, 200, 15, 50)

    canvas.mainloop()


def draw_triangle(canvas, x1, y1, x2, y2, x3, y3):
    """
    This function draws a triangle at the three given coordinates by drawing
    three lines that connect them.
    """
    canvas.create_line(x1, y1, x2, y2)
    canvas.create_line(x2, y2, x3, y3)
    canvas.create_line(x3, y3, x1, y1)


if __name__ == '__main__':
    main()
