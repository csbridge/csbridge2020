"""
File: move_to_center.py
------------------------
This program draws an optical illusion of a checkerboard pattern.
"""

from graphics import Canvas
import time

# These constants tell the graphics canvas how big to be.  You can ignore them.
# Use get_canvas_width() and get_canvas_height() instead.
CANVAS_WIDTH = 540
CANVAS_HEIGHT = 430

# The size of each dimension of the square. use this!
SIZE = 100

DELAY = 1 / 50




def main():
    canvas = Canvas(CANVAS_WIDTH, CANVAS_HEIGHT)
    canvas.set_canvas_title("Move to center")

    top_y = CANVAS_HEIGHT / 2 - SIZE / 2
    rect = canvas.create_rectangle(0, top_y, SIZE, top_y + SIZE)
    canvas.set_color(rect, 'black')

    while not is_past_center(canvas, rect):
        print(canvas.get_left_x(rect))
        canvas.move(rect, 1, 0)

        # animation loop
        canvas.update()
        time.sleep(DELAY)

    canvas.mainloop()


def is_past_center(canvas, rect):
    # returns True if the rectangle is past the center
    x = canvas.get_left_x(rect)
    return x > CANVAS_WIDTH / 2

if __name__ == '__main__':
    main()
