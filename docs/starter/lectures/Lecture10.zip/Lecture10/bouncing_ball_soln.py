"""
File: move_to_center.py
------------------------
This program draws an optical illusion of a checkerboard pattern.
"""

from graphics import Canvas
import time

CANVAS_WIDTH = 540
CANVAS_HEIGHT = 430

BALL_SIZE = 30
DELAY = 1 / 10
INITIAL_CHANGE = 5

def main():
    canvas = Canvas(CANVAS_WIDTH, CANVAS_HEIGHT)
    canvas.set_canvas_title("Move to center")

    ball = make_ball(canvas)

    change_x = INITIAL_CHANGE
    change_y = INITIAL_CHANGE
    while True:
        print('change_x = ', change_x, 'change_y = ',change_y)
        canvas.move(ball, change_x, change_y)
        if hit_bottom_wall(canvas, ball) or hit_top_wall(canvas, ball):
            change_y *= -1
        if hit_left_wall(canvas, ball) or hit_right_wall(canvas, ball):
            change_x *= -1
        canvas.update()
        time.sleep(DELAY)

    canvas.mainloop()

def make_ball(canvas):
    # this function creates a blue ball, and returns it!
    ball = canvas.create_oval(0, 0, BALL_SIZE, BALL_SIZE)
    canvas.set_color(ball, 'blue')
    return ball


def hit_bottom_wall(canvas, ball):
    """
    Returns True if the ball has hit the bottom wall
    """
    y = canvas.get_top_y(ball)
    return y > CANVAS_HEIGHT - BALL_SIZE

def hit_left_wall(canvas, ball):
    """
    Returns True if the ball has hit the left wall
    """
    x = canvas.get_left_x(ball)
    return x < 0

def hit_right_wall(canvas, ball):
    """
    Returns True if the ball has hit the right wall
    """
    x = canvas.get_left_x(ball)
    return x > CANVAS_WIDTH - BALL_SIZE

def hit_top_wall(canvas, ball):
    """
    Returns True if the ball has hit the top wall
    """
    y = canvas.get_top_y(ball)
    return y < 0


if __name__ == '__main__':
    main()
