def main():
    wish1 = input("Enter your wish: ")
    wish2 = input("Enter your wish: ")
    wish3 = input("Enter your wish: ")
    wish4 = input("Enter your wish: ")
    wish5 = input("Enter your wish: ")
    wish6 = input("Enter your wish: ")
    wish7 = input("Enter your wish: ")
    wish8 = input("Enter your wish: ")
    wish9 = input("Enter your wish: ")
    wish10 = input("Enter your wish: ")
    # do something with your wishes
    print("Your wish is " + wish1)
    print("Your wish is " + wish2)
    print("Your wish is " + wish3)
    print("Your wish is " + wish4)
    print("Your wish is " + wish5)
    print("Your wish is " + wish6)
    print("Your wish is " + wish7)
    print("Your wish is " + wish8)
    print("Your wish is " + wish9)
    print("Your wish is " + wish10)


if __name__ == '__main__':
    main()
