def main():
    wish1 = input("Enter your wish: ")
    wish2 = input("Enter your wish: ")
    # do something with your wishes
    print("Your wish is " + wish1)
    print("Your wish is " + wish2)


if __name__ == '__main__':
    main()
