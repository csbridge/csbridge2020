"""
File: draw_pyramid.py
-----------------------
Draws a pyramid out of 10 lines
"""
from graphics import Canvas
PYRAMID_SIZE = 10

def main():
    canvas = Canvas()
    canvas.set_canvas_title("Draw Pyramid")


    x1 = canvas.get_canvas_width()/2
    y1 = 0
    y2 = canvas.get_canvas_height()

    for i in range(PYRAMID_SIZE):
        x2 = i * (canvas.get_canvas_width()/ (PYRAMID_SIZE-1))
        canvas.create_line(x1, y1, x2, y2)
    canvas.mainloop()



if __name__ == "__main__":
    main()
