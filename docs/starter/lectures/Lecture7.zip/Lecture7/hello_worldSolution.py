# This program displays a label with text.

from graphics import Canvas


def main():
    canvas = Canvas(400, 200)
    canvas.set_canvas_title("Canvas")
    canvas.create_text(100, 100, 'Hello World')
    canvas.mainloop()

if __name__ == "__main__":
    main()
