"""
File: programming_is_awesome.py
-------------------
Shows the awesomeness of graphics.
"""

from graphics import Canvas

def main():

    canvas = Canvas(400, 200)
    canvas.set_canvas_title("Programming is Awesome")
    rect = canvas.create_rectangle(5,10,50,100)
    canvas.create_text(100,100, 'hi')
    oval = canvas.create_oval(5,10,50,100)
    canvas.set_fill_color(oval, 'yellow')
    canvas.set_outline_color(oval, 'red')
    canvas.create_text(150,50, 'Programing is awesome')
    canvas.mainloop()

    canvas.mainloop()

# call the function
if __name__ == '__main__':
    main()
