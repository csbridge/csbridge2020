"""
File: programming_is_awesome.py
-------------------
Shows the awesomeness of graphics.
"""

from graphics import Canvas

def main():

    canvas = Canvas(600, 400)
    canvas.set_canvas_title("Programming is Awesome")
    print(canvas.get_canvas_width())
    print(canvas.get_canvas_height())
    canvas.create_image(10, 10, 'MyProject.JPG')
    canvas.create_image_with_size(10, 10, 580, 380, 'MyProject.JPG')
    canvas.create_rectangle(20, 30, 100, 100, fill='red')
    canvas.create_line(0, 200, 600, 200)
    canvas.create_line(300, 0, 300, 400)
    oval = canvas.create_oval(20, 30, 100,100)
    canvas.set_outline_color(oval, 'orange')
    canvas.set_fill_color(oval, 'green')
    canvas.create_text(20,30, 'Hello World')
    canvas.create_text(canvas.get_canvas_width()/2, canvas.get_canvas_height()/2, 'Hello World', anchor='nw')

    canvas.mainloop()


    # TODO: your code here

    canvas.mainloop()

# call the function
if __name__ == '__main__':
    main()
