"""
File: draw_pyramid.py
-----------------------
Draws a pyramid out of 10 lines
"""
from graphics import Canvas
PYRAMID_SIZE = 10

def main():
    pass




if __name__ == "__main__":
    main()
