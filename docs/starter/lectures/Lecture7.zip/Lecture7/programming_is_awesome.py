"""
File: programming_is_awesome.py
-------------------
Shows the awesomeness of graphics.
"""

from graphics import Canvas

def main():
    pass

    # TODO: your code here

    canvas.mainloop()

# call the function
if __name__ == '__main__':
    main()

