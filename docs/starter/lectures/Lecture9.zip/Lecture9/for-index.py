"""
File: for-index.py
-------------------
This program prints the values of index variable of a for-loop.
"""

NUM = 5


def main():
    for i in range(NUM):
        print("i = " + str(i))


if __name__ == '__main__':
    main()
