"""
File: rolldice.py
--------------------
An example simulating rolling two dice
"""

def main():
    pass

# This provided line is required at the end of a Python file
# to call the main() function.
if __name__ == '__main__':
    main()
