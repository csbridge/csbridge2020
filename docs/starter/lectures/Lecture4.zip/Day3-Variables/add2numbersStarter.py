"""
File: add2numbers.py
--------------------
Another python program to get some practice with variables.
This program asks the user for two integers and prints their sum.
"""

def main():
    pass


# This provided line is required at the end of a Python file
# to call the main() function.
if __name__ == '__main__':
    main()
