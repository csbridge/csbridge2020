from karel.stanfordkarel import *

"""
File: hurdle_jumper.py
------------------------
Karel runs a set of hurdles that are 9 avenues long.
Hurdles are of arbitrary height and placement.
"""


def main():
    """
    Delete the line below and write your code here.
    """
    pass


# There is no need to edit code beyond this point

if __name__ == "__main__":
    run_karel_program()
