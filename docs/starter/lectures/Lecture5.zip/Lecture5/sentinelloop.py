"""
File: sentinelloop.py
------------------
Simulate rolling two dice, and prints results of each
roll as well as the total.
"""
SENTINAL_VALUE = ''

def main():
    print('Enter numbers and I will sum them.')
    print('Press enter to finish.')
    total = 0
    user_input = '0'

    while user_input != SENTINAL_VALUE:
        user_input = input("Next item $")
        if user_input != SENTINAL_VALUE:
            total += float(user_input)

    print(total)

# This provided line is required at the end of a Python file
# to call the main() function.
if __name__ == '__main__':
    main()