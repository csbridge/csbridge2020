import random

def main():
    value = random.randint(1, 6)
    print(value)


# This provided line is required at the end of a Python file
# to call the main() function.
if __name__ == '__main__':
    main()