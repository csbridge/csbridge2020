"""
File: some_sum.py
-------------------
This program reads in 10 numbers from the user and prints
out the sum of those 10 numbers.
"""


def main():
    """
    You should replace this comment with a better, more descriptive one.
    You should delete the `pass` line below before writing your code.
    """
    pass


if __name__ == '__main__':
    main()
