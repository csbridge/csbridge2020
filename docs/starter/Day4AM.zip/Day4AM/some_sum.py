"""
File: some_sum.py
-------------------
Write a program that reads in 10 integers from the user
and then outputs the sum of the entered values.
"""

def main():
    """
    You should replace this comment with a better, more descriptive one.
    You should delete the `pass` line below before writing your code.
    """
    pass

# call the function
if __name__ == '__main__':
    main()
