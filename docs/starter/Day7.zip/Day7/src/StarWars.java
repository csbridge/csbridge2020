/*
 * File: StarWars.java
 * -----------------------
 * A GraphicsProgram that uses an ArrayList of GLabels
 * to read in text and scroll it up the screen like in Star Wars.
 * 
 * Public domain image from http://www.publicdomainpictures.net/pictures/130000/velka/night-sky-background-14391263141jp.jpg
 * -----------------------
 */

import acm.program.*;
import acm.util.*;
import java.applet.*;
import java.awt.*;
import java.io.*;
import java.util.*;
import acm.graphics.*;

public class StarWars extends GraphicsProgram implements FileUtil {
	
	private static final String TEXT_FILENAME = "res/opening-crawl.txt";
	private static final String BACKGROUND_IMAGE = "res/background.jpg";
	
	private static final double LABEL_PADDING = 15;	
	private static final double PAUSE_TIME = 20;
	
	public void run() {	
	    // your code here
	}
}
