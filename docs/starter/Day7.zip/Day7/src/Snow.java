import java.util.ArrayList;

import acm.graphics.*;
import acm.program.GraphicsProgram;
import acm.util.RandomGenerator;

public class Snow extends GraphicsProgram {

	private RandomGenerator rg = new RandomGenerator();

	public void run() {
		// your code here...
	}

}