import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JButton;
import acm.graphics.GMath;
import acm.graphics.GRect;
import acm.program.ConsoleProgram;


public class SortedNumbers extends ConsoleProgram{
	
	
	public void run() {
		// your code here.
	}

}
