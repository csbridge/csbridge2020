import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JButton;
import acm.graphics.GMath;
import acm.graphics.GRect;
import acm.program.ConsoleProgram;


public class SortedNumbers extends ConsoleProgram implements FileUtil{
	
	
	public void run() {
		ArrayList<String> lines = readFile("x.txt");
		for (int i = 0; i < lines.size(); i++) {
			println(lines.get(i));
		}
	}

}
