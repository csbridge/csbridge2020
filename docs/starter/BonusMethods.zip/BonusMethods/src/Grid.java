import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class Grid extends GraphicsProgram {

	/** The size of the screen **/
	public static final int APPLICATION_WIDTH = 400;
	public static final int APPLICATION_HEIGHT = 400;
	
	public static final int BOX_LEN = 50;
	public static final int GAP = 5;
	public void run() {
		// your code here...
	}
}
