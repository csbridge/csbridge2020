import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class Fibonacci extends ConsoleProgram {
	
	public void run() {
		fibonacci(60);
		fibonacci(500);
	}
	
	private void fibonacci(int val) {
		
	}
}
