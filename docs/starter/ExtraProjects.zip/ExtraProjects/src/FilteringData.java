import java.awt.Color;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import acm.graphics.GCompound;
import acm.graphics.GLabel;
import acm.graphics.GLine;
import acm.program.GraphicsProgram;
/*
 * This sample project targets demonstration of:
 * - File reading (see method readFromFile)
 * - Creating a graphical object containing of many graphical objects (see method createGraph)
 * - Cycling through elements of an array (see method max)
 * - Processing data in an array (see method movingAverage)
 * */

public class FilteringData extends GraphicsProgram{
	private static final int OFFSET_FROM_SIDES = 30;
	public void run(){
		/*Reading data from file into an array
		 * Takes in name of the file and 
		 * returns the data in an array*/
		double[] dataArray=readFromFile("USDTRYtable.txt");

		/*Plotting data and its filtered version--------------*/
		
		//Setting the origin for the plot
		int originX=OFFSET_FROM_SIDES;
		int originY=getHeight()-OFFSET_FROM_SIDES;
		
		/*Find maximum value of the array to compute a scaling factor
		 * that ensures plot to fit to the canvas*/
		double scaleFactor=(getHeight()-OFFSET_FROM_SIDES*2)/max(dataArray);
		
		//Plotting the original data together with axis lines and labels ('true' turns on axis plotting)
		GCompound graph=createGraph(dataArray,originX,originY,true,scaleFactor);
		add(graph);

		/*Filtering the data using a moving average filter
		 * 
		 * Moving average filter computes average a sub-array for each element containing:
		 *  {'numPointsOnOneSide' samples on the left of the element, 
		 *  the element, 
		 *  'numPointsOnOneSide' samples on the right of the element}
		 *  */
		int numPointsOnOneSide=15;//experiment also using other values
		double[] filtArray=movingAverage(dataArray,numPointsOnOneSide);

		//Plotting filtered data (without axis lines and labels)
		GCompound filtGraph=createGraph(filtArray,originX,originY,false,scaleFactor);
		filtGraph.setColor(Color.RED);
		add(filtGraph);

	}
	/**
	 * Method: movingAverage
	 * ----------------------
	 * Moving average filter computes a new series of data
	 * every i.th point of the new series is obtained as
	 * the average of 2d+1 data points: data[i-d] to data[i+d] 
	 * 
	 * For further information:
	 * https://www.investopedia.com/terms/m/movingaverage.asp
	 * http://www.statisticshowto.com/moving-average/
	 */
	private double[] movingAverage(double[] data,int d){
		double[] filtered=new double[data.length];
		for(int i=d;i<data.length-d;i++){
			double sum=0;
			for(int j=-d;j<=d;j++){
				sum+=data[i+j];
			}
			filtered[i]=sum/(2*d+1);
		}
		return filtered;
	}
	/**
	 * Method: max
	 * ----------------------
	 * This method finds and returns the maximum value in a double array 
	 */
	private double max(double[] data) {
		double max=Double.MIN_VALUE;
		for(int i=0;i<data.length;i++) {
			if(max<data[i]) {
				max=data[i];
			}
		}
		return max;
	}

	/**
	 * Method: createGraph
	 * ----------------------
	 * This method creates a graph from an array
	 * It creates an empty GCompound object and adds GLines to it
	 * that connect data points in the array. 
	 */
	private GCompound createGraph(double[] data,int originX,int originY,boolean addAxisComponents, double scaleFact){

		GCompound graph=new GCompound();
		//adding lines between consecutive data points 
		for(int i=0;i<data.length-1;i++){
			GLine l=new GLine(originX+i,originY-data[i]*scaleFact,originX+i+1,originY-data[i+1]*scaleFact);
			graph.add(l);
		}

		//Adding axis components
		if(addAxisComponents){
			//adding lines for axis
			GLine xax=new GLine(originX,originY,originX+data.length,originY);
			graph.add(xax);
			GLine yax=new GLine(originX,originY,originX,originX);
			graph.add(yax);
			//adding labels
			GLabel origin=new GLabel("(0,0)");
			graph.add(origin,0,originY);
			GLabel yLabel=new GLabel("Value");
			graph.add(yLabel,0,originX);
			GLabel xLabel=new GLabel("Index");
			graph.add(xLabel,originX+data.length/2,originY);
		}
		return graph;
	}
	/**
	 * Method: readDoubleArray
	 * ----------------------
	 * This method reads a file containing values in each line into a double array. 
	 */
	private double[] readFromFile(String filename){
		try {
			/*Reading data from a file with unknown size*/
			BufferedReader rd=new BufferedReader(new FileReader(filename));
			ArrayList<Double> dataList=new ArrayList<Double>();
			while(true){//reading until end of file is reached
				String line=rd.readLine();
				if(line==null){
					rd.close();break;
				}
				dataList.add(Double.parseDouble(line));
			}
			
			/*File read, size of the arraylist is accessible
			 * we can now copy content to an array with a fixed length*/
			double[] data=new double[dataList.size()];
			for(int i=0;i<dataList.size();i++){
				data[i]=dataList.get(i);
			}
			return data;
		} catch (IOException e) {
			e.printStackTrace();return null;
		}
	}
}
