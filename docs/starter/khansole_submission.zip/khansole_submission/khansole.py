"""
File: khansole_academy.py
-------------------------
This program quizzes the user with addition problems and provides feedback
on whether they are correct or incorrect.  The program finishes when
the user gets three problems correct in a row.

NOTE: this program is not complete!  It doesn't yet properly keep track of the number
of correct answers in a row.
"""

import random


NEEDED_CORRECT_IN_A_ROW = 3

MIN_ADD_NUMBER = 10
MAX_ADD_NUMBER = 99


def main():
    while True:
        addend1 = random.randint(MIN_ADD_NUMBER, MAX_ADD_NUMBER)
        addend2 = random.randint(MIN_ADD_NUMBER, MAX_ADD_NUMBER)

        print("What is " + str(addend1) + " + " + str(addend2) + "?")
        guess = int(input("Your answer: "))
        total = addend1 + addend2

        if guess != total:
            print("Incorrect.  The expected answer is " + str(total))
        else:
            print("Correct!")


if __name__ == "__main__":
    main()
